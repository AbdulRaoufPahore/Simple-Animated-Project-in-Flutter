// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool iconButton = false;
  bool blackButton = false;
  Color backgroundColor = Colors.white;
  var boxShadow = BoxShadow(
    offset: Offset(6, 6),
    color: Colors.black,
    blurRadius: 16,
  
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: () {
                setState(() {
                  if (iconButton == false) {
                    iconButton = true;
               
                  } else if (iconButton == true) {
                    iconButton = false;
                  
                  }
                });
              },
              child: AnimatedContainer(
                duration: Duration(milliseconds: 2000),
             
                margin: EdgeInsets.symmetric(vertical: 80),
                width: 170,
                height: 170,
                decoration: iconButton
                    ? BoxDecoration(
                        color: Colors.white,
                      )
                    : BoxDecoration(
                        color: Colors.grey[200],
                        border: iconButton
                            ? Border.all()
                            : Border.all(
                                color: iconButton ? Colors.white : Colors.black,
                                width: iconButton ? 0 : 5,
                              ),
                        borderRadius: iconButton
                            ? BorderRadius.zero
                            : BorderRadius.circular(14),
                        boxShadow: iconButton ? [] : [boxShadow],
                      ),
                child: Icon(
                  Icons.apple,
                  size: 150,
                  color: Colors.black,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                setState(() {
                  if (blackButton == false) {
                    blackButton = true;
                    backgroundColor = Colors.black;
                    boxShadow = BoxShadow(
                      offset: Offset(6, 6),
                      color: Colors.white,
                      blurRadius: 16,
                     
                    );
                  } else if (blackButton == true) {
                    blackButton = false;
                    backgroundColor = Colors.white;
                    boxShadow = BoxShadow(
                      offset: Offset(6, 6),
                      color: Colors.black,
                      blurRadius: 16,
                    
                    );
                  }
                });
              },
              child: AnimatedContainer(
                duration: Duration(),
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                    color: blackButton ? Colors.white : Colors.black,
                    shape: BoxShape.circle,
                    border: blackButton
                        ? Border.all(
                            width: 5,
                            color: Colors.black,
                          )
                        : Border.all(
                            width: 5,
                            color: Colors.white,
                          ),
                    boxShadow: blackButton
                        ? [
                            BoxShadow(
                                offset: Offset(5, 5),
                                color: Colors.white,
                                blurRadius: 15,
                                spreadRadius: 1)
                          ]
                        : [
                            BoxShadow(
                                offset: Offset(5, 5),
                                color: Colors.black,
                                blurRadius: 15,
                                spreadRadius: 1)
                          ]),
              ),
            )
          ],
        ),
      ),
    );
  }
}
